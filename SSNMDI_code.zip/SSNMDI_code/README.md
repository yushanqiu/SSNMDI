SSNMDI

a novel joint learning model of semi-supervised non-negative matrix factorization and data imputation for clustering of single cell RNA-seq data
Author: Yan Chang: yanchang0310@163.com Maintainer: Yushan Qiu: yushan.qiu@szu.edu.cn 

SSNMDI is written in the MATLAB programming language. To use, please download the SSNMDI folder and follow the instructions provided in the README.

Files：

SSNMDI_model.m - The main function.

main_SSNMDI.m - A script with a real scRNA-seq data to show how to run the code.

Zheng_pre.mat - A real scRNA-seq data used in the cell type clustering example. The dataset has been preprocessed.

constructW.m - Compute adjacent matrix W.

labelA.m - Construct label constraint matrix A.

SoftThreshold.m - Calculation of the imputation matrix S.

NormalizeUV.m - Normalize data.

NormalizeUZ.m - Normalize data.

bestMap.m - permute labels of L2 to match L1 as good as possible.

compute_NMI.m - Program for calculating the Normalized Mutual Information (NMI) between two clusterings.

AMI.m - Program for calculating the Adjusted Mutual Information (AMI) between two clusterings.

ARI.m - Program for calculating the Adjusted Rand Index ( Hubert & Arabie) between two clusterings.

hungarian.m - Solve the Assignment problem using the Hungarian method.


