    clear all;
    clc;    
%%%%%%%%%%%%%%%%%%%%输入数据%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    load('Zheng_pre.mat')%Loading data
    X=A;
    label=labels;
%%%%%%%%%%%%%抽取标签数据%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    k2=length(unique(label));%类别数
    scala = 0.2;  % 每一类中，训练集抽取的比例
    X_1 = [];
    X_2 = [];
    y_1 = [];
    y_2 = [];
    c = [];
    for labell=1:length(unique(label))
        cate = find(label==labell);
        half = ceil(length(cate)*scala);
%         half = int32(length(cate)*scala);
        local = randperm(length(cate),half);
        local_lab = cate(local);  %当前类下，抽取的训练集的所在行
        local_non = setdiff(cate,local_lab);   % 当前类下，剩余的也就是测试集的所在行
        X_1 = [X_1,X(:,local_lab)];
        X_2 = [X_2,X(:,local_non)];
        y_1 = [y_1;label(local_lab,:)];
        y_2 = [y_2;label(local_non,:)];
        c = [c;label(local_lab)];
    end
    X = [X_1,X_2];
    label = [y_1;y_2];
    A = labelA(label,c,k2);
    %==============计算图正则化项==============
    options = [];
    option.Metric = 'Cosine';
    options.NeighborMode = 'KNN';%KNN
    options.k =5;%5 nearest neighbors
    options.WeightMode = 'Cosine';%Weights are 0 or 1, it can eplace with 'HeatKernel', 'Euclidean' 

    W = constructW(X',options);

    clear options;
    options = [];
    
    %%%%%%%%%%%%%%%%%%参数设置%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    num = length(c);
    lambda=2;%参数lambda由网格搜索得到
    k1=500; 
    %%%%%%%%%%%%%%%%%%模型迭代%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    [U_final,Z_final,B_final, F_final, S_final] = SSNMDI_model(X,A,lambda,k1,k2,W,options,num);
 
    %%%%%%%%%%% Clustering cell type label
        for e=1:size(F_final,2) %%返回矩阵F_final列数（遍历cell）
        v=F_final(:,e);
        ma=max(v);
        [s,t]=find(v==ma);
        l(e)=s;
        end
        %%%%%%%%%%%%%%==================Performance evaluation===============================
        label(1:num,:)=[];
        ll=label;%%%  the label originally identified by the authors
        l=l';
        l(1:num,:)=[];
        [newl] = bestMap(ll,l);%% Permute label of l to match ll as good as possible 新的pre_label矩阵
        nmi=compute_NMI(ll,newl) %% Calculating the Normalized Mutual Information (NMI)
        ami=AMI(ll,newl)%% Calculating the Adjusted Mutual Information (AMI)
        ari = ARI(ll,max(ll),newl,max(newl)) %% Calculating the Adjusted Rand Index (ARI)
        pre_label =newl;
        if ~isempty(ll) %%假如A为空的话，返回的值是0，假如A为非空的话，返回的值是1
        exact = find(pre_label == ll);
        accuracy = length(exact)/length(newl) %% Calculating the accuracy
        else
        accuracy = []
        end
